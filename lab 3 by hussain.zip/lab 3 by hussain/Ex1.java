import java.util.Scanner;
class Ex1{
	public static void main(String[]args){
		Scanner input=new Scanner(System.in);
		System.out.println("Enter Starting range");
		int start=input.nextInt();
		System.out.println("Enter Ending range");
		int end=input.nextInt();
		
		for (int num=start; num<=end; num++)
		{
		
		boolean isPrime=true;
		for (int i=2; i<num; i++){
			if (num%i==0){
				isPrime=false;
				break;
			}
		}
		if (isPrime){
			System.out.println(num);

		}
		}
	}
}
