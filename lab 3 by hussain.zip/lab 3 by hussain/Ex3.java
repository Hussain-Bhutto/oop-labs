import java.util.Scanner;
class Ex3{
	public static void main(String[]args){
		int row=3;
		int col=4;
		int[][] arr = new int[row][col];
        arr[0][0] = 12;
		arr[0][1] = 13 ;
		arr[0][2] = 15;
		arr[0][3] = 16;

		arr[1][0] = 11;
		arr[1][1] = 110 ;
		arr[1][2] = 121;
		arr[1][3] = 17;
		
		arr[2][0] = 17;
		arr[2][1] = 18 ;
		arr[2][2] = 100;
		arr[2][3] = 21;
		
for (int i=0; i<row; i++){
	for ( int j=0; j<col; j++){  

if (arr[i][j]%2==0){
	arr[i][j]=arr[i][j]/2;	
	}
	}
}

System.out.println("Now, here are odd numbers");
for (int i=0; i<row; i++){
	for ( int j=0; j<col; j++){  

if (arr[i][j]%2!=0){
	System.out.println(arr[i][j]);	
	}
	}
}

int sum_even=0;
for (int i=0; i<row; i++){
	for (int j=0; j<col; j++){
		if (arr[i][j]%2==0){
			sum_even+=arr[i][j];
			
		}
	}
	
}
			System.out.println("Sum of updated even numbers: " + sum_even);

	}
}
